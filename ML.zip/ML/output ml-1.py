Python 3.12.9 (tags/v3.12.9:fdb8142, Feb  4 2025, 15:27:58) [MSC v.1942 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
============= RESTART: C:/Users/gkzee/OneDrive/Desktop/question5.py ============
Q1: Number of pairs with sum 10: 2
Q2: Range of the list: 6.2
Q3: Matrix power result:
[7, 10]
[15, 22]
Q4: p occurs 3 times
Q5: Generated numbers: [1, 1, 1, 2, 3, 3, 3, 4, 4, 4, 5, 5, 5, 5, 6, 6, 6, 6, 6, 7, 7, 7, 9, 10, 10]
Mean: 5.04
Median: 5
Mode: 6
